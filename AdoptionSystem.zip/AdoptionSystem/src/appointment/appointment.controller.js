'use strict'

import Animal from '../animal/animal.model.js'
import Appointment from './appointment.model.js'

export const test = async (req, res) => {
    return res.send({ message: 'Function test is running | appointment' })
}

//el nombre create lo podemos cambiar
export const save = async (req, res) => {
    try {
        //Capturar la data
        let data = req.body;
        data.user = req.user._id //Jalar el id del usuario logeado!!
        //Verificar que exista animal
        let animal = Animal.findOne({ _id: data.animal })
        if (!animal) return res.status(404).send({ message: 'Animal not found' })
        //Validar que la mascota no tenga una vita activa con esa persona
        //EJERCICIO: que el usuario no pueda tener mas de una cita por dia.
        let existAppointment = await Appointment.findOne({
            $or: [
                {
                    animal: data.animal,
                    user: data.user,
                },
                {
                    date: data.date,
                    user: data.user
                }
            ]
        })
        //if anidado dentro de la consulta
        if (existAppointment) return res.send({ message: 'You cannot have more than one appointment a day.' })

        //Guardar
        let appointment = new Appointment(data)
        await appointment.save()
        return res.send({ message: `Appointment saved succesfully in date ${appointment.date}` })
    } catch (err) {
        console.error(err)
        return res.status(500).send({ message: 'Error creating appointment', err })
    }
}